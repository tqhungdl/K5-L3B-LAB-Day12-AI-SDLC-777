# <github-handle> — phản tư cá nhân (≤ 200 từ)

- Tôi đã làm (kèm link commit):
- Tôi đã review (kèm link):
- AI sai ở đâu và tôi phát hiện thế nào:
- Điều tôi học được:
